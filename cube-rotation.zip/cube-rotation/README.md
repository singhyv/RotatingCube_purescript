# README #


### TOCOMPILE ###

* spago i
* spago build -w


###To run it in WEB###

* spago bundle-app --to dist/app.js

Then open 
$ project_dir/dist/index.html to see the cube


Dev Workflow: Make changes to files in src and it will automatically compile. Reload index.html in the browser. 